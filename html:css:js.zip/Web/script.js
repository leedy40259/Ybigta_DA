function tonaver() {
    location.href = "https://map.naver.com/v5/entry/place/31964075?c=14130258.27835131,4517035.711960187,13,0,0,0,dh&placePath=%2Fhome&entry=plt";
}